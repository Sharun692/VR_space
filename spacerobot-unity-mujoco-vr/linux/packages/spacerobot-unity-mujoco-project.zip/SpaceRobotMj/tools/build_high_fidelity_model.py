from pathlib import Path
import xml.etree.ElementTree as ET


HERE = Path(__file__).resolve().parent
OUTPUT = HERE / "spacerobot_high_fidelity.xml"

LEGS = {
    "FL": ((0.36, 0.28, 0.0), 0.0),
    "FR": ((0.36, -0.28, 0.0), 0.0),
    "RL": ((-0.36, 0.28, 0.0), 3.141592653589793),
    "RR": ((-0.36, -0.28, 0.0), 3.141592653589793),
}
INITIAL_ANCHORS = {
    "FL": (-2.25, 0.60, 0.58),
    "FR": (-2.25, -0.60, 0.58),
    "RL": (-3.15, 0.60, 0.58),
    "RR": (-3.15, -0.60, 0.58),
}
UPPER_LENGTH = 0.46
FOREARM_LENGTH = 0.42


def s(value):
    if isinstance(value, (tuple, list)):
        return " ".join(f"{x:.9g}" for x in value)
    return str(value)


def add(parent, tag, **attrs):
    return ET.SubElement(parent, tag, {key: s(value) for key, value in attrs.items()})


def add_station_capsule(parent, name, p1, p2, radius, mass=3.0, material="truss"):
    return add(
        parent,
        "geom",
        name=name,
        type="capsule",
        fromto=(*p1, *p2),
        size=radius,
        mass=mass,
        material=material,
        **{"class": "station_collision"},
    )


def add_finger(palm, leg, index, x_sign, side_sign, actuators):
    base = add(
        palm,
        "body",
        name=f"{leg}_finger{index}_prox_body",
        pos=(0.045 * x_sign, 0.075 * side_sign, -0.015),
    )
    j1 = f"{leg}_finger{index}_prox"
    add(base, "joint", name=j1, type="hinge", axis=(1, 0, 0), range=(-1.65, 1.05), damping=0.025, armature=0.0004)
    add(
        base,
        "geom",
        name=f"{leg}_finger{index}_prox_geom",
        type="capsule",
        fromto=(0, 0, 0, 0, 0, -0.070),
        size=0.012,
        mass=0.028,
        **{"class": "finger_collision"},
    )
    distal = add(base, "body", name=f"{leg}_finger{index}_dist_body", pos=(0, 0, -0.070))
    j2 = f"{leg}_finger{index}_dist"
    add(distal, "joint", name=j2, type="hinge", axis=(1, 0, 0), range=(-1.65, 1.20), damping=0.018, armature=0.0003)
    add(
        distal,
        "geom",
        name=f"{leg}_finger{index}_dist_geom",
        type="capsule",
        fromto=(0, 0, 0, 0, 0, -0.060),
        size=0.010,
        mass=0.020,
        **{"class": "finger_collision"},
    )
    add(distal, "site", name=f"{leg}_finger{index}_tip", pos=(0, 0, -0.060), size=0.008, rgba=(0.95, 0.65, 0.15, 0.8))
    actuators.extend(((j1, 20, 4.0), (j2, 18, 3.5)))


def add_leg(robot, leg, shoulder_pos, heading, actuators):
    upper_length = UPPER_LENGTH
    forearm_length = FOREARM_LENGTH
    yaw_body = add(robot, "body", name=f"{leg}_yaw_body", pos=shoulder_pos, euler=(0, 0, heading))
    add(yaw_body, "joint", name=f"{leg}_yaw", type="hinge", axis=(0, 0, 1), range=(-2.45, 2.45), damping=1.4, armature=0.025)
    add(yaw_body, "geom", name=f"{leg}_shoulder_shell", type="cylinder", size=(0.075, 0.045), mass=0.55, material="joint", **{"class": "robot_collision"})

    pitch_body = add(yaw_body, "body", name=f"{leg}_pitch_body")
    add(pitch_body, "joint", name=f"{leg}_pitch", type="hinge", axis=(0, 1, 0), range=(-1.60, 2.30), damping=1.8, armature=0.035)
    add(pitch_body, "geom", name=f"{leg}_upper_geom", type="capsule", fromto=(0, 0, 0, upper_length, 0, 0), size=0.046, mass=1.35, material="limb", **{"class": "robot_collision"})

    elbow = add(pitch_body, "body", name=f"{leg}_elbow_body", pos=(upper_length, 0, 0))
    add(elbow, "joint", name=f"{leg}_elbow", type="hinge", axis=(0, 1, 0), range=(0.05, 2.55), damping=1.6, armature=0.030)
    add(elbow, "geom", name=f"{leg}_elbow_shell", type="sphere", size=0.055, mass=0.32, material="joint", **{"class": "robot_collision"})
    add(elbow, "geom", name=f"{leg}_forearm_geom", type="capsule", fromto=(0, 0, 0, forearm_length, 0, 0), size=0.040, mass=1.05, material="limb", **{"class": "robot_collision"})

    wrist_yaw = add(elbow, "body", name=f"{leg}_wrist_yaw_body", pos=(forearm_length, 0, 0))
    add(wrist_yaw, "inertial", pos=(0, 0, 0), mass=0.035, diaginertia=(0.00008, 0.00008, 0.00008))
    add(wrist_yaw, "joint", name=f"{leg}_wrist_yaw", type="hinge", axis=(0, 0, 1), range=(-3.14, 3.14), damping=0.22, armature=0.003)
    wrist_pitch = add(wrist_yaw, "body", name=f"{leg}_wrist_pitch_body")
    add(wrist_pitch, "inertial", pos=(0, 0, 0), mass=0.035, diaginertia=(0.00008, 0.00008, 0.00008))
    add(wrist_pitch, "joint", name=f"{leg}_wrist_pitch", type="hinge", axis=(0, 1, 0), range=(-3.14, 3.14), damping=0.22, armature=0.003)
    palm = add(wrist_pitch, "body", name=f"{leg}_palm")
    add(palm, "joint", name=f"{leg}_wrist_roll", type="hinge", axis=(1, 0, 0), range=(-3.14, 3.14), damping=0.25, armature=0.004)
    add(palm, "geom", name=f"{leg}_palm_geom", type="box", size=(0.082, 0.078, 0.025), mass=0.42, material="palm", **{"class": "robot_collision"})
    add(palm, "site", name=f"{leg}_grasp_site", pos=(0, 0, -0.090), size=0.012, rgba=(0.1, 1.0, 0.35, 0.45))

    finger_index = 0
    for side_sign in (1, -1):
        for x_sign in (1, -1):
            finger_index += 1
            add_finger(palm, leg, finger_index, x_sign, side_sign, actuators)

    actuators.extend(
        (
            (f"{leg}_yaw", 80, 35),
            (f"{leg}_pitch", 120, 55),
            (f"{leg}_elbow", 100, 45),
            (f"{leg}_wrist_yaw", 30, 10),
            (f"{leg}_wrist_pitch", 30, 10),
            (f"{leg}_wrist_roll", 20, 6),
        )
    )


def build():
    root = ET.Element("mujoco", model="spacerobot_articulated_service_robot")
    add(root, "compiler", angle="radian", autolimits="true", balanceinertia="true")
    add(
        root,
        "option",
        timestep=0.001,
        gravity=(0, 0, -8.7e-6),
        integrator="implicitfast",
        solver="Newton",
        cone="elliptic",
        iterations=80,
        tolerance=1e-10,
        noslip_iterations=4,
    )
    add(root, "size", njmax=20000, nconmax=3000)

    visual = add(root, "visual")
    add(visual, "global", azimuth=132, elevation=-18, offwidth=1600, offheight=900)
    add(visual, "quality", shadowsize=4096)
    add(visual, "headlight", diffuse=(0.78, 0.79, 0.82), ambient=(0.10, 0.11, 0.14), specular=(0.35, 0.35, 0.38))

    defaults = add(root, "default")
    station_default = add(defaults, "default", **{"class": "station_collision"})
    add(station_default, "geom", contype=1, conaffinity=6, condim=6, friction=(0.92, 0.012, 0.002), solref=(0.004, 1), solimp=(0.96, 0.995, 0.001))
    robot_default = add(defaults, "default", **{"class": "robot_collision"})
    add(robot_default, "geom", contype=2, conaffinity=1, condim=4, friction=(0.75, 0.01, 0.001), solref=(0.005, 1), solimp=(0.95, 0.995, 0.001))
    finger_default = add(defaults, "default", **{"class": "finger_collision"})
    add(finger_default, "geom", contype=4, conaffinity=1, condim=6, friction=(1.45, 0.025, 0.004), solref=(0.008, 1), solimp=(0.94, 0.995, 0.001))
    deco_default = add(defaults, "default", **{"class": "decorative"})
    add(deco_default, "geom", contype=0, conaffinity=0)

    assets = add(root, "asset")
    add(assets, "texture", name="space", type="skybox", builtin="gradient", width=1024, height=1024, rgb1=(0, 0, 0), rgb2=(0.001, 0.002, 0.008))
    materials = {
        "truss": ((0.82, 0.84, 0.82, 1), 0.72, 0.8),
        "station": ((0.42, 0.45, 0.47, 1), 0.55, 0.65),
        "blanket": ((0.86, 0.87, 0.84, 1), 0.38, 0.5),
        "solar": ((0.012, 0.055, 0.16, 1), 0.45, 0.55),
        "joint": ((0.025, 0.027, 0.032, 1), 0.55, 0.7),
        "limb": ((0.58, 0.61, 0.63, 1), 0.62, 0.75),
        "palm": ((0.10, 0.11, 0.13, 1), 0.5, 0.7),
        "cap": ((0.95, 0.58, 0.10, 1), 0.72, 0.8),
        "earth_ocean": ((0.01, 0.16, 0.62, 1), 0.18, 0.25),
        "earth_land": ((0.05, 0.40, 0.13, 1), 0.16, 0.2),
    }
    for name, (rgba, specular, shininess) in materials.items():
        add(assets, "material", name=name, rgba=rgba, specular=specular, shininess=shininess)

    world = add(root, "worldbody")
    add(world, "light", pos=(-8, -8, 10), dir=(1, 1, -1), directional="true", diffuse=(0.95, 0.93, 0.88))
    add(world, "light", pos=(7, 5, 6), dir=(-1, -1, -1), directional="true", diffuse=(0.24, 0.27, 0.33))
    add(world, "geom", name="earth", type="sphere", pos=(-10, 7, -5), size=2.8, material="earth_ocean", **{"class": "decorative"})
    add(world, "geom", name="earth_africa", type="ellipsoid", pos=(-9.35, 5.1, -4.2), size=(0.76, 0.14, 0.55), euler=(0.2, 0.1, 0.7), material="earth_land", **{"class": "decorative"})
    add(world, "geom", name="earth_eurasia", type="ellipsoid", pos=(-8.95, 5.4, -5.1), size=(1.0, 0.13, 0.42), euler=(-0.1, 0.25, -0.35), material="earth_land", **{"class": "decorative"})

    station = add(world, "body", name="station")
    add(station, "freejoint", name="station_free")
    add(station, "inertial", pos=(0, 0, 0.08), mass=20000, diaginertia=(75000, 450000, 500000))
    add(station, "geom", name="central_node", type="box", pos=(0, 0, 0.05), size=(0.72, 0.62, 0.32), mass=420, material="station", **{"class": "station_collision"})
    add(station, "geom", name="central_blanket", type="box", pos=(0, 0, 0.405), size=(0.76, 0.66, 0.025), mass=22, material="blanket", **{"class": "station_collision"})

    add(station, "geom", name="lab_port", type="cylinder", fromto=(-2.7, 0, 0.05, -0.72, 0, 0.05), size=0.38, mass=310, material="blanket", **{"class": "station_collision"})
    add(station, "geom", name="lab_starboard", type="cylinder", fromto=(0.72, 0, 0.05, 2.7, 0, 0.05), size=0.38, mass=310, material="blanket", **{"class": "station_collision"})
    add(station, "geom", name="node_fore", type="cylinder", fromto=(0, 0.60, 0.10, 0, 2.1, 0.10), size=0.34, mass=210, material="station", **{"class": "station_collision"})
    add(station, "geom", name="node_aft", type="cylinder", fromto=(0, -0.60, 0.10, 0, -2.1, 0.10), size=0.34, mass=210, material="station", **{"class": "station_collision"})
    add(station, "geom", name="docking_fore", type="cylinder", fromto=(0, 2.1, 0.10, 0, 2.35, 0.10), size=0.42, mass=48, material="joint", **{"class": "station_collision"})
    add(station, "geom", name="docking_aft", type="cylinder", fromto=(0, -2.1, 0.10, 0, -2.35, 0.10), size=0.42, mass=48, material="joint", **{"class": "station_collision"})

    for y in (-0.60, 0.60):
        for z in (-0.20, 0.58):
            add_station_capsule(station, f"rail_y{y:+.2f}_z{z:+.2f}", (-8, y, z), (8, y, z), 0.035, mass=86)
    for i, x in enumerate(range(-8, 9)):
        add_station_capsule(station, f"top_rung_{i:02d}", (x, -0.60, 0.58), (x, 0.60, 0.58), 0.024, mass=5)
        add_station_capsule(station, f"bottom_rung_{i:02d}", (x, -0.60, -0.20), (x, 0.60, -0.20), 0.022, mass=4)
        if i < 16:
            xn = x + 1.0
            for y in (-0.60, 0.60):
                z1, z2 = ((0.58, -0.20) if i % 2 == 0 else (-0.20, 0.58))
                diagonal_y = 0.30 if y > 0 else -0.30
                add_station_capsule(station, f"side_diag_{i:02d}_{'p' if y > 0 else 'n'}", (x, diagonal_y, z1), (xn, diagonal_y, z2), 0.018, mass=3)

    for x in (-5.2, 5.2):
        for side in (-1, 1):
            y_panel = 3.75 * side
            add_station_capsule(station, f"boom_{x:+.1f}_{side:+d}", (x, 0.60 * side, 0.12), (x, y_panel - 1.15 * side, 0.12), 0.045, mass=26)
            add(station, "geom", name=f"panel_{x:+.1f}_{side:+d}", type="box", pos=(x, y_panel, 0.12), size=(1.45, 1.08, 0.025), mass=45, material="solar", **{"class": "station_collision"})
            for gx in (-0.96, -0.48, 0, 0.48, 0.96):
                add(station, "geom", name=f"panel_grid_{x:+.1f}_{side:+d}_{gx:+.2f}", type="box", pos=(x + gx, y_panel, 0.15), size=(0.010, 1.08, 0.008), mass=0.2, material="blanket", **{"class": "decorative"})

    for x in (-3.4, 3.4):
        add_station_capsule(station, f"radiator_boom_{x:+.1f}", (x, 0.60, 0.35), (x, 1.35, 0.35), 0.030, mass=10)
        add(station, "geom", name=f"radiator_{x:+.1f}", type="box", pos=(x, 1.62, 0.35), size=(0.72, 0.45, 0.025), euler=(0.22, 0, 0), mass=20, material="blanket", **{"class": "station_collision"})

    add(station, "geom", name="service_platform", type="box", pos=(3.15, -1.10, 0.67), size=(0.38, 0.18, 0.07), mass=42, material="station", **{"class": "station_collision"})
    add(station, "geom", name="service_guard_left", type="capsule", fromto=(2.80, -1.29, 0.75, 3.00, -1.29, 0.75), size=0.020, mass=2, material="truss", **{"class": "station_collision"})
    add(station, "geom", name="service_guard_right", type="capsule", fromto=(3.30, -1.29, 0.75, 3.50, -1.29, 0.75), size=0.020, mass=2, material="truss", **{"class": "station_collision"})
    add_station_capsule(station, "service_brace_b", (3.48, -0.92, 0.62), (3.48, -0.60, -0.20), 0.022, mass=4)
    add_station_capsule(station, "service_brace_d", (3.48, -1.28, 0.62), (3.48, -0.60, -0.20), 0.022, mass=4)

    # Fixed valve pedestal closes the physical/visual gap between the platform
    # and the rotating cap. The cap assembly is 0.10 m closer to the robot.
    add(station, "geom", name="service_cap_pedestal", type="cylinder", pos=(3.05, -1.00, 0.7775), size=(0.032, 0.0375), mass=1.2, material="joint", contype="0", conaffinity="0")
    add(station, "geom", name="service_cap_flange", type="cylinder", pos=(3.05, -1.00, 0.805), size=(0.062, 0.010), mass=0.8, material="joint", contype="0", conaffinity="0")
    cap = add(station, "body", name="service_cap", pos=(3.05, -1.00, 0.86))
    add(cap, "joint", name="cap_hinge", type="hinge", axis=(0, 0, 1), range=(0, 1.65), damping=0.20, frictionloss=0.08, armature=0.010)
    add(cap, "geom", name="service_cap_geom", type="cylinder", size=(0.045, 0.045), mass=0.28, material="cap", **{"class": "station_collision"})
    for angle, pos in enumerate(((0.049, 0, 0), (-0.049, 0, 0), (0, 0.049, 0), (0, -0.049, 0))):
        add(cap, "geom", name=f"cap_rib_{angle}", type="box", pos=pos, size=(0.010, 0.018, 0.040), mass=0.012, material="cap", **{"class": "station_collision"})
    add(cap, "site", name="cap_target", pos=(0, 0, 0), size=0.010, rgba=(1, 0.2, 0.1, 0.6))

    for leg, anchor in INITIAL_ANCHORS.items():
        add(station, "site", name=f"rail_target_{leg}", pos=anchor, size=0.010, rgba=(0.1, 0.8, 1.0, 0.45))

    robot = add(world, "body", name="robot", pos=(-2.70, 0, 1.18))
    add(robot, "freejoint", name="robot_free")
    add(robot, "geom", name="robot_torso", type="box", size=(0.38, 0.29, 0.14), mass=42, material="station", **{"class": "robot_collision"})
    add(robot, "geom", name="robot_top_shell", type="box", pos=(0, 0, 0.16), size=(0.22, 0.18, 0.055), mass=5.5, material="palm", **{"class": "robot_collision"})
    add(robot, "geom", name="robot_sensor", type="cylinder", pos=(0.12, 0, 0.235), size=(0.065, 0.025), mass=0.45, material="joint", **{"class": "robot_collision"})

    actuators = []
    for leg, (shoulder_pos, heading) in LEGS.items():
        add_leg(robot, leg, shoulder_pos, heading, actuators)

    equality = add(root, "equality")
    for leg in LEGS:
        add(equality, "connect", name=f"rail_latch_{leg}", site1=f"{leg}_grasp_site", site2=f"rail_target_{leg}", active="false", solref=(0.008, 1), solimp=(0.94, 0.995, 0.001))
    add(equality, "connect", name="cap_latch_FR", site1="FR_grasp_site", site2="cap_target", active="false", solref=(0.015, 1), solimp=(0.90, 0.99, 0.002))

    actuator_root = add(root, "actuator")
    for joint, kp, force in actuators:
        add(actuator_root, "position", name=f"act_{joint}", joint=joint, kp=kp, ctrllimited="true", ctrlrange=(-3.2, 3.2), forcelimited="true", forcerange=(-force, force))

    sensor = add(root, "sensor")
    add(sensor, "jointpos", name="cap_angle", joint="cap_hinge")
    add(sensor, "jointvel", name="cap_rate", joint="cap_hinge")
    add(sensor, "framepos", name="robot_position", objtype="body", objname="robot")
    add(sensor, "framepos", name="station_position", objtype="body", objname="station")

    ET.indent(root, space="  ")
    tree = ET.ElementTree(root)
    tree.write(OUTPUT, encoding="utf-8", xml_declaration=True)
    print(f"Saved {OUTPUT}")


if __name__ == "__main__":
    build()
