using System;
using Mujoco;
using UnityEngine;

namespace SpaceRobot {

// Drives the service mission from inside MuJoCo's own step loop. MuJoCo runs
// in-process: there is no external physics server and no network stream.
public unsafe class SpaceRobotMission : MonoBehaviour {

  [Tooltip("Simulated seconds after which the mission stops advancing. Zero runs indefinitely.")]
  public double Duration = 0.0;

  [Tooltip("Off holds the robot on the rail and never starts the cap sequence, " +
           "leaving the limbs free to be driven from outside.")]
  public bool AutonomousMission = true;

  [Tooltip("MuJoCo steps per rendered frame. The plug-in synchronises every " +
           "component transform after each step it takes, so the physics is " +
           "substepped here and Unity is synchronised once per frame instead.")]
  public int PhysicsSubsteps = 11;

  public const double PhysicsTimestep = 0.001;

  public string Stage => _controller?.Stage ?? "uninitialised";
  public double SimulationTime => _access == null ? 0.0 : _access.Data->time;
  public double CapAngle => _access?.CapAngle ?? 0.0;
  public ContactReport Contacts { get; private set; }

  // Exposed so that external control, such as a tracked hand, can take over a
  // limb. Both are null until the first physics step has run.
  public MissionController Controller => _controller;
  public MjModelAccess Model => _access;

  // Raised once per physics substep with the forces measured by MuJoCo, so a
  // resistive device driver receives samples at the physics rate rather than
  // the frame rate.
  public event Action<ForceSample> ForceSampleAvailable;

  public struct ForceSample {
    public double Time;
    public double CapContactForce;
    public double GripForceFL, GripForceFR, GripForceRL, GripForceRR;
    public int CapFingerContacts;
  }

  private MjScene _scene;
  private MjModelAccess _access;
  private MissionController _controller;
  private ContactClassifier _classifier;
  private Stabilization _stabilization;
  private bool _initialised;

  private void Start() {
    // One MjScene step per frame; the substeps below carry the 1 ms physics.
    Time.fixedDeltaTime = (float)(PhysicsTimestep * PhysicsSubsteps);
    _scene = MjScene.Instance;
    _scene.preUpdateEvent += OnPreUpdate;
  }

  private void OnDestroy() {
    if (_scene != null) _scene.preUpdateEvent -= OnPreUpdate;
  }

  private void OnPreUpdate(object sender, MjStepArgs args) {
    if (!_initialised) {
      _access = new MjModelAccess(args.model, args.data);
      _classifier = new ContactClassifier(_access);
      _stabilization = new Stabilization(_access);
      _stabilization.InitializeModel();
      _controller = new MissionController(_access, _stabilization);
      _initialised = true;
    }

    if (Duration > 0.0 && _access.Data->time >= Duration) return;

    // Advance all but the final substep here. MjScene takes the last one and
    // synchronises the Unity transforms once, after this returns.
    for (int i = 0; i < PhysicsSubsteps - 1; i++) {
      StepOnce();
      MujocoLib.mj_step(_access.Model, _access.Data);
    }
    StepOnce();
  }

  private void StepOnce() {
    _controller.Autonomous = AutonomousMission;
    Contacts = _classifier.Measure(_access);
    _controller.Update(_access.Data->time, Contacts);
    ForceSampleAvailable?.Invoke(new ForceSample {
      Time = _access.Data->time,
      CapContactForce = Contacts.CapContactForce,
      GripForceFL = Contacts.GripForces[Rig.FL],
      GripForceFR = Contacts.GripForces[Rig.FR],
      GripForceRL = Contacts.GripForces[Rig.RL],
      GripForceRR = Contacts.GripForces[Rig.RR],
      CapFingerContacts = Contacts.CapFingerCount(Rig.FR),
    });
  }
}
}
