// Copyright 2019 DeepMind Technologies Limited
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.AnimatedValues;
using UnityEngine;

namespace Mujoco {

  [CustomEditor(typeof(MjSlideJoint))]
  public class MjSlideJointEditor : Editor {
    private MjSlideJoint _joint;

    protected virtual void OnEnable() {
      _joint = (MjSlideJoint)target;
    }

    protected virtual void OnSceneGUI() {
      DrawHandles(_joint);
    }

    // Draw the handles for the slide joint.
    public static void DrawHandles(MjSlideJoint joint) {
      // Draw the handles.
      if (joint.Settings.Solver.Limited) {
        Handles.color = Color.blue;
        MjHandles.LinearLimits(joint.transform.position, joint.RangeLower, joint.RangeUpper,
                                   joint.SlideAxis);
      }
      Handles.color = Color.yellow;
      MjHandles.Axis(joint.transform.position, joint.SlideAxis);
    }
  }
}
